# SAAD Travel Agency — Site Web

Site web statique (1 seule page HTML, sans dépendance backend) pour l'agence SAAD Travel.

## Déploiement sur GitHub Pages

### Étape 1 — Créer le dépôt
1. Va sur https://github.com/new
2. Donne un nom au dépôt, par exemple `saad-travel-agency`
3. Choisis **Public** (obligatoire pour GitHub Pages gratuit, sauf si tu as GitHub Pro)
4. Ne coche pas "Add a README" (on a déjà le nôtre)
5. Clique sur **Create repository**

### Étape 2 — Envoyer les fichiers
**Option A : via l'interface web (le plus simple)**
1. Sur la page du dépôt, clique sur "uploading an existing file"
2. Glisse-dépose `index.html` et `README.md`
3. Clique sur **Commit changes**

**Option B : via Git en ligne de commande**
```bash
git clone https://github.com/TON-USERNAME/saad-travel-agency.git
cd saad-travel-agency
# copie index.html et README.md dans ce dossier
git add .
git commit -m "Site SAAD Travel Agency"
git push origin main
```

### Étape 3 — Activer GitHub Pages
1. Dans le dépôt, va dans **Settings** (Paramètres)
2. Dans le menu à gauche, clique sur **Pages**
3. Sous "Build and deployment" → Source : choisis **Deploy from a branch**
4. Branch : choisis **main** et le dossier **/ (root)**
5. Clique sur **Save**

### Étape 4 — Accéder au site
Après 1-2 minutes, ton site sera disponible à l'adresse :
```
https://TON-USERNAME.github.io/saad-travel-agency/
```

## Notes techniques
- Le fichier est **100% autonome** : HTML + CSS + JavaScript intégrés dans un seul fichier, logo encodé en base64 directement dans le code.
- Les seules ressources externes sont les **polices Google Fonts** (Fraunces, Cairo, Work Sans, Noto Naskh Arabic), chargées via CDN — elles fonctionneront normalement sur GitHub Pages.
- Le fichier doit s'appeler **`index.html`** (et pas `saad-travel-agency_site.html`) pour que GitHub Pages l'affiche automatiquement comme page d'accueil.
- Aucune configuration supplémentaire n'est nécessaire (pas de build, pas de `package.json`).

## Nom de domaine personnalisé (optionnel)
Si tu as un nom de domaine (ex: `saadtravel.ma`), tu peux l'ajouter dans Settings → Pages → Custom domain, puis configurer un enregistrement CNAME chez ton fournisseur de domaine pointant vers `TON-USERNAME.github.io`.
